# use:
# \-> flask to create the webserver,
#  \-> request to handle inputs and
#   \-> send_from_directory to serve files.
from flask import Flask, request, send_from_directory

# setup server app
app = Flask(__name__)

# serve index at http://localhost:80/
@app.route('/')
def index():
    return "Try to open <a href='/page1'>page 1</a>"

# play a game after login
@app.route('/pacman', methods=['GET','POST'])
def game():
    if request.method == 'GET':
        return "Need to <a href='/login'>login</a> first!"
    elif request.method == 'POST':
        template = open("pages/pacman.html","r").read()
        replacement = request.form['firstname'] + ' ' + request.form['lastname']
        response = template.replace("<NAME-TO-BE-REPLACED>", replacement)
        return response
    else:
        return 'Error - Unsupported HTTP method!'

# serve subpages
@app.route('/<page>')
def serve_page(page):
    return open("pages/"+page+".html","r").read()

# serve files (images, audio, etc...)
@app.route('/files/<name>')
def serve_image(name):
    return send_from_directory('files', name)

# start the server app
if __name__ == "__main__":
    app.run(host='0.0.0.0',port=80,debug=True)
